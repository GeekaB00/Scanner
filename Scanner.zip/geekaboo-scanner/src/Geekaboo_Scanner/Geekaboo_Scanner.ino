/*
  GEEKABOO MULTI SCANNER  v2.6.0
  Boards (picked automatically from User_Setup.h in this sketch folder):
    ESP32-2432S028   2.8"  240x320  ILI9341  resistive touch (XPT2046, own SPI bus)
    ESP32-3248S035R  3.5"  320x480  ST7796   resistive touch (XPT2046, shared SPI bus)
    ESP32-3248S035C  3.5"  320x480  ST7796   capacitive touch (GT911, I2C)
  To build for a board, copy its file from User_Setups/ to User_Setup.h in this folder.
  Author: Geekaboo
  ---------------------------------------------------------------
  Boot: "Geek Scanner" image, touch to continue.
  Tabs:
    BLE   - nearby Bluetooth LE devices, sorted by signal
    WIFI  - 2.4 GHz access points (SSID, BSSID, channel, security)
    CHAN  - Wi-Fi channel analyzer (overlap graph + best channel)
    TAGS  - tracker detector (Apple Find My, Samsung SmartTag, Tile, Google Find Hub)
    MESH  - MeshCore companion radios advertising over BLE ("MeshCore-<node>"),
            other Nordic UART devices, and MeshCore-OTA Wi-Fi access points
  Tap any list row for a detail page with a large signal meter.
  Footer: UP / PAUSE / ROTATE / SETTINGS / DOWN.
  Settings (saved to flash): min signal, hide stale, scan time, forget after,
  tracker alert time, brightness, invert colours, touch calibration.
  Touch calibration: runs by itself on the first boot of a 3.5" board, from
  Settings, or by holding a finger on the boot screen for 3 seconds.

  LED: blue = BLE scan, green = Wi-Fi scan, red flash = new tracker seen,
       magenta = waiting on boot screen.

  Libraries: TFT_eSPI (Bodmer), XPT2046_Touchscreen (Paul Stoffregen, 2.8" board only)
  Board: ESP32 Dev Module, Partition: Huge APP (3MB No OTA)
*/

#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <Preferences.h>
#include <TFT_eSPI.h>
#include <BLEDevice.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>

// =====================================================================
// Board: detected from User_Setup.h (the TFT_eSPI display config in this
// sketch folder). Copy the right file from User_Setups/ to User_Setup.h.
// =====================================================================
#if TFT_HEIGHT == 320
  #define BOARD_CYD28
#elif TFT_HEIGHT == 480 && defined(TOUCH_CS)
  #define BOARD_CYD35R
#elif TFT_HEIGHT == 480
  #define BOARD_CYD35C
#else
  #error "Unknown display: copy a file from User_Setups/ to User_Setup.h in the sketch folder"
#endif

#if defined(BOARD_CYD28)
  #define BOARD_NAME  "ESP32-2432S028 2.8in"
  #define BL_PIN      21
  #define DEFAULT_INV true          // matches TFT_INVERSION_ON in its User_Setup.h
  #define TOUCH_XPT_OWN_BUS
  #include <XPT2046_Touchscreen.h>
  #include "splash_image.h"         // 240x320
  #ifdef TOUCH_CS
    #error "Remove TOUCH_CS from User_Setup.h for the 2.8in board (touch has its own SPI bus)"
  #endif
#elif defined(BOARD_CYD35R)
  #define BOARD_NAME  "ESP32-3248S035R 3.5in"
  #define BL_PIN      27
  #define DEFAULT_INV false
  #define TOUCH_XPT_SHARED
  #include "splash_image_35.h"      // 320x480
#elif defined(BOARD_CYD35C)
  #define BOARD_NAME  "ESP32-3248S035C 3.5in"
  #define BL_PIN      27
  #define DEFAULT_INV false
  #define TOUCH_GT911
  #include <Wire.h>
  #include "splash_image_35.h"      // 320x480
#endif

// ---------- Identity ----------
#define FW_AUTHOR  "Geekaboo"
#define FW_NAME    "MULTI SCANNER"
#define FW_VERSION "2.6.0"

// ---------- Pins shared by all boards ----------
#define LED_R 4      // RGB LED, active LOW
#define LED_G 16
#define LED_B 17

// ---------- Touch pins per board ----------
#if defined(TOUCH_XPT_OWN_BUS)      // 2.8": XPT2046 on its own SPI bus
  #define T_IRQ  36
  #define T_MOSI 32
  #define T_MISO 39
  #define T_CLK  25
  #define T_CS   33
#elif defined(TOUCH_GT911)          // 3.5" C: GT911 on I2C
  #define GT_SDA 33
  #define GT_SCL 32
  #define GT_INT 21
  #define GT_RST 25
#endif                              // 3.5" R: TOUCH_CS 33 lives in User_Setup.h

// ---------- Colours ----------
#define C_BG     TFT_BLACK
#define C_CYAN   0x07FF
#define C_MAG    0xF81F
#define C_TEXT   0xCE79
#define C_DIM    0x632C
#define C_ROW_A  0x0841
#define C_ROW_B  0x10A2
#define C_GREEN  0x07E0
#define C_YELLOW 0xFFE0
#define C_RED    0xF800
#define C_ORANGE 0xFD20

// ---------- Layout (W/H change with rotation) ----------
#define HEAD_H  22
#define TAB_H   22
#define LIST_Y  (HEAD_H + TAB_H + 2)
#define ROW_H   26
#define FOOT_H  30
int W = 240, H = 320, FOOT_Y = 290, ROWS = 9;
uint8_t rot = 0;                 // 0 = portrait (default)

// ---------- Fixed scan constants ----------
#define STALE_MS     10000       // grey out after 10 s
#define MAX_DEVS     64
#define MAX_APS      48

// ---------- Settings (saved in flash) ----------
const int8_t   OPT_MINRSSI[] = { 0, -90, -80, -70 };     // 0 = off
const uint8_t  OPT_SCAN[]    = { 2, 3, 5 };              // BLE scan pass, seconds
const uint16_t OPT_FORGET[]  = { 30, 60, 300 };          // seconds
const uint8_t  OPT_TAG[]     = { 5, 10, 20, 30 };        // minutes
const uint8_t  OPT_BRIGHT[]  = { 25, 50, 75, 100 };      // percent

struct Settings {
  uint8_t  minRssi = 0, hideStale = 0, scan = 1, forget = 1, tag = 1, bright = 3, invert = 0;
} set;

uint32_t forgetMs()  { return (uint32_t)OPT_FORGET[set.forget] * 1000UL; }
uint32_t tagWarnMs() { return (uint32_t)OPT_TAG[set.tag] * 60000UL; }

enum Mode : uint8_t { M_BLE, M_WIFI, M_CHAN, M_TAGS, M_MESH, M_COUNT };
const char *MODE_NAMES[M_COUNT] = { "BLE", "WIFI", "CHAN", "TAGS", "MESH" };

// ---------- MeshCore (from MeshCore companion_radio firmware) ----------
#define MESH_PREFIX "MeshCore-"                                   // BLE name prefix
#define NUS_UUID    "6e400001-b5a3-f393-e0a9-e50e24dcca9e"        // Nordic UART service
enum MeshType : uint8_t { MESH_NONE, MESH_NUS, MESH_COMPANION };

enum TagType : uint8_t { TAG_NONE, TAG_APPLE, TAG_SAMSUNG, TAG_TILE, TAG_GOOGLE };
const char *TAG_NAMES[] = { "-", "Apple Find My", "Samsung SmartTag", "Tile", "Google Find Hub" };

struct Dev {
  char     addr[18];
  char     name[40];
  int      rssi;
  int8_t   txPower;
  bool     hasTx;
  uint16_t mfgId;
  bool     hasMfg;
  uint8_t  mfg[16];
  uint8_t  mfgLen;
  char     uuid[40];
  uint8_t  tag;
  uint8_t  mesh;
  uint32_t firstSeen, lastSeen;
  uint16_t hits;
};

struct AP {
  char     ssid[33];
  char     bssid[18];
  int      rssi;
  uint8_t  ch;
  uint8_t  enc;
  uint32_t firstSeen, lastSeen;
  uint16_t hits;
};

TFT_eSPI tft;
#if defined(TOUCH_XPT_OWN_BUS)
SPIClass touchSPI(VSPI);
XPT2046_Touchscreen ts(T_CS, T_IRQ);
#endif
Preferences prefs;
int NW = 240, NH = 320;            // native portrait size (rotation 0), set in setup()

// shared with scan task
Dev devs[MAX_DEVS]; int devCount = 0;
AP  aps[MAX_APS];   int apCount  = 0;
SemaphoreHandle_t dataMutex;

// UI snapshots
Dev vDev[MAX_DEVS]; int vDevCount = 0;
AP  vAp[MAX_APS];   int vApCount  = 0;
int tagIdx[MAX_DEVS]; int tagCount = 0;
// MESH list mixes BLE devices (idx >= 0) and Wi-Fi APs (encoded as -1 - apIndex)
int meshIdx[MAX_DEVS + MAX_APS]; int meshCount = 0;

volatile Mode     mode       = M_BLE;
volatile bool     paused     = false;
volatile bool     newTagSeen = false;
volatile bool     scanning   = false;

enum Screen { LIST, DETAIL, SETTINGS };
Screen  screen = LIST;
Mode    detailMode = M_BLE;
int     scrollPos = 0;
char    selKey[18] = "";
uint32_t tagFlashUntil = 0;

// =====================================================================
// Settings storage
// =====================================================================
void setBacklight() {
  ledcWrite(BL_PIN, (uint32_t)OPT_BRIGHT[set.bright] * 255 / 100);
}

// "Invert colours" flips the panel's normal setting (some panels ship inverted)
void applyInvert() {
  tft.invertDisplay(DEFAULT_INV ^ (set.invert != 0));
}

void loadSettings() {
  set.minRssi   = min<uint8_t>(prefs.getUChar("minr",   0), 3);
  set.hideStale = min<uint8_t>(prefs.getUChar("stale",  0), 1);
  set.scan      = min<uint8_t>(prefs.getUChar("scan",   1), 2);
  set.forget    = min<uint8_t>(prefs.getUChar("forget", 1), 2);
  set.tag       = min<uint8_t>(prefs.getUChar("tag",    1), 3);
  set.bright    = min<uint8_t>(prefs.getUChar("bright", 3), 3);
  set.invert    = min<uint8_t>(prefs.getUChar("invert", 0), 1);
}

void saveSettings() {
  prefs.putUChar("minr",   set.minRssi);
  prefs.putUChar("stale",  set.hideStale);
  prefs.putUChar("scan",   set.scan);
  prefs.putUChar("forget", set.forget);
  prefs.putUChar("tag",    set.tag);
  prefs.putUChar("bright", set.bright);
  prefs.putUChar("invert", set.invert);
}

// =====================================================================
// BLE scanning
// =====================================================================
uint8_t detectTag(BLEAdvertisedDevice &d) {
  if (d.haveManufacturerData()) {
    auto m = d.getManufacturerData();
    // Apple company ID 0x004C, payload type 0x12 = Find My / offline finding
    if (m.length() >= 3 && (uint8_t)m[0] == 0x4C && (uint8_t)m[1] == 0x00 && (uint8_t)m[2] == 0x12)
      return TAG_APPLE;
  }
  const BLEUUID tile1((uint16_t)0xFEED), tile2((uint16_t)0xFEEC);
  const BLEUUID smart((uint16_t)0xFD5A), fmdn((uint16_t)0xFEAA);
  for (int i = 0; i < d.getServiceUUIDCount(); i++) {
    BLEUUID u = d.getServiceUUID(i);
    if (u.equals(tile1) || u.equals(tile2)) return TAG_TILE;
    if (u.equals(smart)) return TAG_SAMSUNG;
  }
  for (int i = 0; i < d.getServiceDataCount(); i++) {
    BLEUUID u = d.getServiceDataUUID(i);
    if (u.equals(smart)) return TAG_SAMSUNG;
    if (u.equals(tile1) || u.equals(tile2)) return TAG_TILE;
    if (u.equals(fmdn)) {                       // Eddystone UUID; 0x40/0x41 = Find Hub frame
      auto s = d.getServiceData(i);
      if (s.length() && ((uint8_t)s[0] == 0x40 || (uint8_t)s[0] == 0x41)) return TAG_GOOGLE;
    }
  }
  return TAG_NONE;
}

bool isMeshAP(const AP &a) { return strncmp(a.ssid, "MeshCore", 8) == 0; }

uint8_t detectMesh(BLEAdvertisedDevice &d) {
  if (d.haveName()) {
    auto n = d.getName();
    if (strncmp(n.c_str(), MESH_PREFIX, strlen(MESH_PREFIX)) == 0) return MESH_COMPANION;
  }
  for (int i = 0; i < d.getServiceUUIDCount(); i++) {
    auto u = d.getServiceUUID(i).toString();
    if (strcasecmp(u.c_str(), NUS_UUID) == 0) return MESH_NUS;
  }
  return MESH_NONE;
}

class ScanCB : public BLEAdvertisedDeviceCallbacks {
  void onResult(BLEAdvertisedDevice d) override {
    auto a = d.getAddress().toString();
    uint8_t tag = detectTag(d);
    uint8_t mesh = detectMesh(d);
    xSemaphoreTake(dataMutex, portMAX_DELAY);

    int idx = -1;
    for (int i = 0; i < devCount; i++)
      if (strcmp(devs[i].addr, a.c_str()) == 0) { idx = i; break; }
    if (idx < 0) {
      if (devCount < MAX_DEVS) idx = devCount++;
      else {
        idx = 0;
        for (int i = 1; i < devCount; i++)
          if (devs[i].lastSeen < devs[idx].lastSeen) idx = i;
      }
      memset(&devs[idx], 0, sizeof(Dev));
      strlcpy(devs[idx].addr, a.c_str(), sizeof(devs[idx].addr));
      devs[idx].firstSeen = millis();
      if (tag) newTagSeen = true;
    }

    Dev &e = devs[idx];
    e.rssi = d.getRSSI();
    e.lastSeen = millis();
    e.hits++;
    if (tag) e.tag = tag;
    if (mesh > e.mesh) e.mesh = mesh;
    if (d.haveName()) {
      auto n = d.getName();
      if (n.length()) strlcpy(e.name, n.c_str(), sizeof(e.name));
    }
    if (d.haveTXPower()) { e.txPower = d.getTXPower(); e.hasTx = true; }
    if (d.haveManufacturerData()) {
      auto m = d.getManufacturerData();
      if (m.length() >= 2) {
        e.mfgId  = ((uint8_t)m[1] << 8) | (uint8_t)m[0];
        e.hasMfg = true;
        e.mfgLen = min((int)m.length(), (int)sizeof(e.mfg));
        for (int i = 0; i < e.mfgLen; i++) e.mfg[i] = (uint8_t)m[i];
      }
    }
    if (d.haveServiceUUID()) {
      auto u = d.getServiceUUID().toString();
      strlcpy(e.uuid, u.c_str(), sizeof(e.uuid));
    }
    xSemaphoreGive(dataMutex);
  }
};

BLEScan *bleScan;

void blePass() {
  scanning = true;
  digitalWrite(LED_B, LOW);
  bleScan->start(OPT_SCAN[set.scan], false);
  digitalWrite(LED_B, HIGH);
  bleScan->clearResults();
  scanning = false;
}

// =====================================================================
// Wi-Fi scanning
// =====================================================================
void wifiPass() {
  scanning = true;
  digitalWrite(LED_G, LOW);
  int n = WiFi.scanNetworks(false, true);       // blocking, include hidden
  digitalWrite(LED_G, HIGH);
  scanning = false;
  if (n <= 0) { WiFi.scanDelete(); return; }

  uint32_t now = millis();
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  for (int i = 0; i < n; i++) {
    String b = WiFi.BSSIDstr(i);
    int idx = -1;
    for (int j = 0; j < apCount; j++)
      if (strcmp(aps[j].bssid, b.c_str()) == 0) { idx = j; break; }
    if (idx < 0) {
      if (apCount < MAX_APS) idx = apCount++;
      else {
        idx = 0;
        for (int j = 1; j < apCount; j++)
          if (aps[j].lastSeen < aps[idx].lastSeen) idx = j;
      }
      memset(&aps[idx], 0, sizeof(AP));
      strlcpy(aps[idx].bssid, b.c_str(), sizeof(aps[idx].bssid));
      aps[idx].firstSeen = now;
    }
    AP &a = aps[idx];
    strlcpy(a.ssid, WiFi.SSID(i).c_str(), sizeof(a.ssid));
    a.rssi = WiFi.RSSI(i);
    a.ch = WiFi.channel(i);
    a.enc = (uint8_t)WiFi.encryptionType(i);
    a.lastSeen = now;
    a.hits++;
  }
  xSemaphoreGive(dataMutex);
  WiFi.scanDelete();
}

void prune() {
  uint32_t now = millis(), lim = forgetMs();
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  for (int i = 0; i < devCount;) {
    if (now - devs[i].lastSeen > lim) devs[i] = devs[--devCount]; else i++;
  }
  for (int i = 0; i < apCount;) {
    if (now - aps[i].lastSeen > lim) aps[i] = aps[--apCount]; else i++;
  }
  xSemaphoreGive(dataMutex);
}

void scanTask(void *) {
  static uint8_t meshRound = 0;
  for (;;) {
    if (paused) { vTaskDelay(pdMS_TO_TICKS(100)); continue; }
    Mode m = mode;
    if (m == M_WIFI || m == M_CHAN) wifiPass();
    else if (m == M_MESH && (++meshRound & 3) == 0) wifiPass();
    else blePass();
    prune();
    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

// =====================================================================
// Helpers
// =====================================================================
int cmpDev(const void *a, const void *b) { return ((const Dev *)b)->rssi - ((const Dev *)a)->rssi; }
int cmpAp (const void *a, const void *b) { return ((const AP  *)b)->rssi - ((const AP  *)a)->rssi; }
// Settings filters: min signal and hide stale. The item open on a detail page always stays.
bool keepEntry(int rssi, uint32_t lastSeen, const char *key) {
  if (screen == DETAIL && strcmp(key, selKey) == 0) return true;
  if (set.minRssi && rssi < OPT_MINRSSI[set.minRssi]) return false;
  if (set.hideStale && millis() - lastSeen > STALE_MS) return false;
  return true;
}

void takeSnapshot() {
  int nd, na;
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  nd = devCount; memcpy(vDev, devs, sizeof(Dev) * devCount);
  na = apCount;  memcpy(vAp,  aps,  sizeof(AP)  * apCount);
  xSemaphoreGive(dataMutex);

  // apply settings filters in place
  vDevCount = 0;
  for (int i = 0; i < nd; i++) if (keepEntry(vDev[i].rssi, vDev[i].lastSeen, vDev[i].addr)) vDev[vDevCount++] = vDev[i];
  vApCount = 0;
  for (int i = 0; i < na; i++) if (keepEntry(vAp[i].rssi, vAp[i].lastSeen, vAp[i].bssid)) vAp[vApCount++] = vAp[i];

  qsort(vDev, vDevCount, sizeof(Dev), cmpDev);
  qsort(vAp,  vApCount,  sizeof(AP),  cmpAp);
  tagCount = 0;
  for (int i = 0; i < vDevCount; i++) if (vDev[i].tag) tagIdx[tagCount++] = i;
  meshCount = 0;
  for (int pass = MESH_COMPANION; pass >= MESH_NUS; pass--)   // companions first
    for (int i = 0; i < vDevCount; i++) if (vDev[i].mesh == pass) meshIdx[meshCount++] = i;
  for (int i = 0; i < vApCount; i++) if (isMeshAP(vAp[i])) meshIdx[meshCount++] = -1 - i;
}

int itemCount(Mode m) {
  switch (m) {
    case M_BLE:  return vDevCount;
    case M_WIFI: return vApCount;
    case M_CHAN: return vApCount;
    case M_TAGS: return tagCount;
    case M_MESH: return meshCount;
    default:     return 0;
  }
}

const char *vendorName(uint16_t id) {
  switch (id) {
    case 0x004C: return "Apple";
    case 0x0006: return "Microsoft";
    case 0x0075: return "Samsung";
    case 0x00E0: return "Google";
    case 0x0059: return "Nordic";
    case 0x02E5: return "Espressif";
    case 0x0087: return "Garmin";
    default:     return nullptr;
  }
}

const char *encName(uint8_t e) {
  switch ((wifi_auth_mode_t)e) {
    case WIFI_AUTH_OPEN:            return "OPEN";
    case WIFI_AUTH_WEP:             return "WEP";
    case WIFI_AUTH_WPA_PSK:         return "WPA";
    case WIFI_AUTH_WPA2_PSK:        return "WPA2";
    case WIFI_AUTH_WPA_WPA2_PSK:    return "WPA/2";
    case WIFI_AUTH_WPA2_ENTERPRISE: return "WPA2-E";
    case WIFI_AUTH_WPA3_PSK:        return "WPA3";
    case WIFI_AUTH_WPA2_WPA3_PSK:   return "WPA2/3";
    default:                        return "?";
  }
}

uint16_t rssiColor(int rssi) {
  if (rssi > -60) return C_GREEN;
  if (rssi > -80) return C_YELLOW;
  return C_RED;
}

void fmtDuration(char *buf, size_t n, uint32_t ms) {
  uint32_t s = ms / 1000;
  if (s < 60)        snprintf(buf, n, "%lus", (unsigned long)s);
  else if (s < 3600) snprintf(buf, n, "%lum %02lus", (unsigned long)(s / 60), (unsigned long)(s % 60));
  else               snprintf(buf, n, "%luh %02lum", (unsigned long)(s / 3600), (unsigned long)((s / 60) % 60));
}

// Draw text, cut to fit maxW pixels (adds '.' when cut)
void drawFit(const char *s, int x, int y, int font, int maxW) {
  char buf[48];
  strlcpy(buf, s, sizeof(buf));
  int n = strlen(buf);
  bool cut = false;
  while (n > 1 && tft.textWidth(buf, font) > maxW) { buf[--n] = 0; cut = true; }
  if (cut && n > 1) buf[n - 1] = '.';
  tft.drawString(buf, x, y, font);
}

// =====================================================================
// Touch: raw reading per board -> calibration -> current rotation
// =====================================================================
#if defined(TOUCH_GT911)
uint8_t gtAddr = 0;
bool    gtDown = false;
int     gtX = 0, gtY = 0;
uint32_t gtLast = 0;

bool gtWrite(uint16_t reg, uint8_t val) {
  Wire.beginTransmission(gtAddr);
  Wire.write(reg >> 8); Wire.write(reg & 0xFF); Wire.write(val);
  return Wire.endTransmission() == 0;
}

bool gtRead(uint16_t reg, uint8_t *buf, uint8_t n) {
  Wire.beginTransmission(gtAddr);
  Wire.write(reg >> 8); Wire.write(reg & 0xFF);
  if (Wire.endTransmission() != 0) return false;
  if (Wire.requestFrom((int)gtAddr, (int)n) != n) return false;
  for (uint8_t i = 0; i < n; i++) buf[i] = Wire.read();
  return true;
}

void gtBegin() {
  // reset with INT low -> GT911 answers on address 0x5D
  pinMode(GT_RST, OUTPUT); pinMode(GT_INT, OUTPUT);
  digitalWrite(GT_RST, LOW); digitalWrite(GT_INT, LOW);
  delay(11);
  digitalWrite(GT_RST, HIGH);
  delay(6);
  pinMode(GT_INT, INPUT);
  delay(60);
  Wire.begin(GT_SDA, GT_SCL, 400000);
  Wire.setTimeOut(20);
  const uint8_t addrs[2] = { 0x5D, 0x14 };
  for (uint8_t a : addrs) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) { gtAddr = a; break; }
  }
  Serial.printf("[touch] GT911 %s (0x%02X)\n", gtAddr ? "found" : "NOT found", gtAddr);
}
#endif

void touchBegin() {
#if defined(TOUCH_XPT_OWN_BUS)
  touchSPI.begin(T_CLK, T_MISO, T_MOSI, T_CS);
  ts.begin(touchSPI);
  ts.setRotation(1);
#elif defined(TOUCH_GT911)
  gtBegin();
#endif                                 // shared-bus XPT2046 is set up by tft.init()
}

// Raw touch values (board units). Returns false when nothing is pressed.
bool touchRaw(int &ra, int &rb) {
#if defined(TOUCH_XPT_OWN_BUS)
  if (!ts.tirqTouched() || !ts.touched()) return false;
  TS_Point p = ts.getPoint();
  ra = p.x; rb = p.y;
  return true;
#elif defined(TOUCH_XPT_SHARED)
  if (tft.getTouchRawZ() < 400) return false;
  uint16_t x, y;
  tft.getTouchRaw(&x, &y);
  ra = x; rb = y;
  return true;
#elif defined(TOUCH_GT911)
  if (!gtAddr) return false;
  uint8_t st;
  if (gtRead(0x814E, &st, 1) && (st & 0x80)) {      // new data ready
    uint8_t n = st & 0x0F;
    uint8_t p[4];
    if (n > 0 && gtRead(0x8150, p, 4)) {
      gtX = p[0] | (p[1] << 8);
      gtY = p[2] | (p[3] << 8);
      gtDown = true; gtLast = millis();
    } else gtDown = false;
    gtWrite(0x814E, 0);
  } else if (gtDown && millis() - gtLast > 80) gtDown = false;
  ra = gtX; rb = gtY;
  return gtDown;
#else
  return false;
#endif
}

bool touchDown() { int a, b; return touchRaw(a, b); }

// Calibration: raw -> native portrait pixels (rotation 0).
// swap = 1 when the raw "b" value follows the screen's x axis.
struct TouchCal { uint8_t swap; int16_t x0, x1, y0, y1; };
#if defined(BOARD_CYD28)
const TouchCal CAL_DEFAULT = { 1, 3785, 240, 200, 3689 };   // same mapping as v2.5.0
const bool CAL_REQUIRED = false;
#elif defined(BOARD_CYD35C)
const TouchCal CAL_DEFAULT = { 0, 0, 319, 0, 479 };         // GT911 usually reports pixels
const bool CAL_REQUIRED = true;
#else
const TouchCal CAL_DEFAULT = { 0, 3800, 250, 250, 3800 };   // guess; calibrated on first boot
const bool CAL_REQUIRED = true;
#endif
TouchCal cal = CAL_DEFAULT;

void loadCal() {
  if (prefs.getBytesLength("cal") == sizeof(TouchCal)) prefs.getBytes("cal", &cal, sizeof(cal));
  else cal = CAL_DEFAULT;
}
bool haveCal() { return prefs.getBytesLength("cal") == sizeof(TouchCal); }
void saveCal() { prefs.putBytes("cal", &cal, sizeof(cal)); }

void rawToNative(int ra, int rb, int &px, int &py) {
  int u = cal.swap ? rb : ra, v = cal.swap ? ra : rb;
  px = constrain(map(u, cal.x0, cal.x1, 0, NW - 1), 0, NW - 1);
  py = constrain(map(v, cal.y0, cal.y1, 0, NH - 1), 0, NH - 1);
}

// native portrait (rotation 0) -> current rotation
void nativeToRot(int px, int py, int &x, int &y) {
  switch (rot) {
    case 0:  x = px;          y = py;          break;
    case 1:  x = py;          y = NW - 1 - px; break;
    case 2:  x = NW - 1 - px; y = NH - 1 - py; break;
    default: x = NH - 1 - py; y = px;          break;
  }
}

// One tap (debounced), in current screen coordinates
bool getTouch(int &x, int &y) {
  static uint32_t last = 0;
  int ra, rb;
  if (!touchRaw(ra, rb)) return false;
  if (millis() - last < 250) return false;
  last = millis();
  int px, py;
  rawToNative(ra, rb, px, py);
  nativeToRot(px, py, x, y);
  return true;
}

void applyRotation() {
  tft.setRotation(rot);
  applyInvert();
  W = tft.width();
  H = tft.height();
  FOOT_Y = H - FOOT_H;
  ROWS = (FOOT_Y - LIST_Y) / ROW_H;
  scrollPos = 0;
}

// =====================================================================
// Drawing: chrome
// =====================================================================
void drawHeaderLeft() {
  tft.fillRect(0, 0, W, HEAD_H, C_BG);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(C_CYAN, C_BG);
  tft.drawString(FW_AUTHOR, 6, HEAD_H / 2, 2);
  tft.setTextColor(C_DIM, C_BG);
  tft.drawString("v" FW_VERSION, 10 + tft.textWidth(FW_AUTHOR, 2), HEAD_H / 2, 2);
}

void drawHeaderRight(const char *txt, uint16_t col) {
  tft.setTextDatum(MR_DATUM);
  tft.setTextColor(col, C_BG);
  tft.drawString(txt, W - 6, HEAD_H / 2, 2);
}

void drawHeader() {
  drawHeaderLeft();
  char buf[24];
  Mode m = (screen == DETAIL) ? detailMode : mode;
  if (paused) snprintf(buf, sizeof(buf), "PAUSED");
  else if (m == M_TAGS) snprintf(buf, sizeof(buf), "%d tag%s", tagCount, tagCount == 1 ? "" : "s");
  else if (m == M_MESH) snprintf(buf, sizeof(buf), "%d node%s", meshCount, meshCount == 1 ? "" : "s");
  else if (m == M_BLE)  snprintf(buf, sizeof(buf), "%d dev", vDevCount);
  else                  snprintf(buf, sizeof(buf), "%d AP", vApCount);
  tft.setTextDatum(MR_DATUM);
  tft.setTextColor(paused ? C_YELLOW : C_MAG, C_BG);
  tft.drawString(buf, W - 16, HEAD_H / 2, 2);

  uint16_t dot = paused ? C_DIM : (scanning ? ((m == M_WIFI || m == M_CHAN) ? C_GREEN : C_CYAN) : C_DIM);
  tft.fillCircle(W - 7, HEAD_H / 2, 3, dot);
}

void drawTabs() {
  int tw = W / M_COUNT;
  for (int i = 0; i < M_COUNT; i++) {
    int x = i * tw;
    bool on = (i == mode);
    tft.fillRect(x, HEAD_H, tw, TAB_H, on ? C_CYAN : C_BG);
    if (!on) tft.drawRect(x, HEAD_H, tw, TAB_H, C_ROW_B);
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(on ? C_BG : C_DIM, on ? C_CYAN : C_BG);
    tft.drawString(MODE_NAMES[i], x + tw / 2, HEAD_H + TAB_H / 2 + 1, 2);
  }
  tft.drawFastHLine(0, HEAD_H + TAB_H, W, C_CYAN);
  tft.drawFastHLine(0, HEAD_H + TAB_H + 1, W, C_BG);
}

enum Btn { B_UP, B_DOWN, B_PAUSE, B_ROT, B_SET };

void drawRotateIcon(int cx, int cy, uint16_t col) {
  tft.drawCircle(cx, cy, 7, col);
  tft.drawCircle(cx, cy, 6, col);
  tft.fillRect(cx - 1, cy - 8, 9, 6, C_BG);          // gap in the ring
  tft.fillTriangle(cx + 1, cy - 9, cx + 1, cy - 2, cx + 6, cy - 6, col);
}

void drawGearIcon(int cx, int cy, uint16_t col) {
  for (int a = 0; a < 8; a++) {                      // teeth
    float r = a * PI / 4;
    int tx = cx + (int)(cos(r) * 8), ty = cy + (int)(sin(r) * 8);
    tft.fillCircle(tx, ty, 2, col);
  }
  tft.fillCircle(cx, cy, 7, col);
  tft.fillCircle(cx, cy, 3, C_BG);
}

void drawButton(Btn b, int cx, int cy) {
  tft.setTextDatum(MC_DATUM);
  switch (b) {
    case B_UP:    tft.fillTriangle(cx, cy - 7, cx - 9, cy + 6, cx + 9, cy + 6, C_CYAN); break;
    case B_DOWN:  tft.fillTriangle(cx, cy + 7, cx - 9, cy - 6, cx + 9, cy - 6, C_CYAN); break;
    case B_PAUSE:
      if (paused) tft.fillTriangle(cx - 5, cy - 8, cx - 5, cy + 8, cx + 8, cy, C_YELLOW);
      else { tft.fillRect(cx - 6, cy - 7, 4, 15, C_MAG); tft.fillRect(cx + 2, cy - 7, 4, 15, C_MAG); }
      break;
    case B_ROT:   drawRotateIcon(cx, cy + 1, C_MAG); break;
    case B_SET:   drawGearIcon(cx, cy, C_MAG); break;
  }
}

void drawFooterBtns(const Btn *btns, int n) {
  tft.fillRect(0, FOOT_Y, W, FOOT_H, C_BG);
  tft.drawFastHLine(0, FOOT_Y, W, C_CYAN);
  int bw = W / n, cy = FOOT_Y + FOOT_H / 2;
  for (int i = 1; i < n; i++) tft.drawFastVLine(i * bw, FOOT_Y + 6, FOOT_H - 12, C_ROW_B);
  for (int i = 0; i < n; i++) drawButton(btns[i], i * bw + bw / 2, cy);
}

const Btn LIST_BTNS[] = { B_UP, B_PAUSE, B_ROT, B_SET, B_DOWN };
void drawFooter() { drawFooterBtns(LIST_BTNS, 5); }

void rssiBar(int x, int y, int w, int h, int rssi, uint16_t col) {
  int fw = constrain(map(rssi, -100, -30, 2, w - 2), 2, w - 2);
  tft.drawRect(x, y, w, h, C_DIM);
  tft.fillRect(x + 1, y + 1, fw, h - 2, col);
  tft.fillRect(x + 1 + fw, y + 1, w - 2 - fw, h - 2, C_BG);
}

void drawScrollbar(int count, int pos, int rows) {
  tft.fillRect(W - 2, LIST_Y, 2, rows * ROW_H, C_BG);
  if (count > rows) {
    int track = rows * ROW_H;
    int h = max(8, track * rows / count);
    int yy = LIST_Y + (track - h) * pos / max(1, count - rows);
    tft.fillRect(W - 2, yy, 2, h, C_MAG);
  }
}

// =====================================================================
// Drawing: list rows
// =====================================================================
void rowRight(int y, uint16_t bg, int rssi, bool stale) {
  uint16_t col = stale ? C_DIM : rssiColor(rssi);
  rssiBar(W - 96, y + 8, 56, 10, rssi, col);
  char buf[8];
  snprintf(buf, sizeof(buf), "%d", rssi);
  tft.setTextDatum(MR_DATUM);
  tft.setTextColor(col, bg);
  tft.drawString(buf, W - 5, y + ROW_H / 2, 2);
}

void drawRowBLE(int y, uint16_t bg, const Dev *d, bool tagView) {
  bool stale = millis() - d->lastSeen > STALE_MS;
  int maxW = W - 106;
  tft.setTextDatum(TL_DATUM);
  char buf[40];

  if (tagView) {
    bool warn = millis() - d->firstSeen > tagWarnMs();
    tft.setTextColor(warn ? C_MAG : (stale ? C_DIM : C_ORANGE), bg);
    drawFit(TAG_NAMES[d->tag], 6, y + 2, 2, maxW);
    char dur[16]; fmtDuration(dur, sizeof(dur), millis() - d->firstSeen);
    snprintf(buf, sizeof(buf), "%s  %s", d->addr, dur);
    tft.setTextColor(warn ? C_MAG : C_DIM, bg);
    drawFit(buf, 6, y + 17, 1, maxW);
  } else {
    const char *v = d->hasMfg ? vendorName(d->mfgId) : nullptr;
    if (d->name[0]) {
      tft.setTextColor(stale ? C_DIM : C_TEXT, bg);
      drawFit(d->name, 6, y + 2, 2, maxW);
    } else {
      snprintf(buf, sizeof(buf), "<%s>", v ? v : "unnamed");
      tft.setTextColor(C_DIM, bg);
      drawFit(buf, 6, y + 2, 2, maxW);
    }
    if (d->tag) snprintf(buf, sizeof(buf), "%s  TAG", d->addr);
    else        strlcpy(buf, d->addr, sizeof(buf));
    tft.setTextColor(stale ? C_DIM : (d->tag ? C_ORANGE : C_CYAN), bg);
    drawFit(buf, 6, y + 17, 1, maxW);
  }
  rowRight(y, bg, d->rssi, stale);
}

void drawRowAP(int y, uint16_t bg, const AP *a) {
  bool stale = millis() - a->lastSeen > STALE_MS;
  int maxW = W - 106;
  tft.setTextDatum(TL_DATUM);
  if (a->ssid[0]) { tft.setTextColor(stale ? C_DIM : C_TEXT, bg); drawFit(a->ssid, 6, y + 2, 2, maxW); }
  else            { tft.setTextColor(C_DIM, bg);                   drawFit("<hidden>", 6, y + 2, 2, maxW); }
  char buf[40];
  snprintf(buf, sizeof(buf), "ch%-2u %-6s %s", a->ch, encName(a->enc), a->bssid);
  tft.setTextColor(stale ? C_DIM : (a->enc == WIFI_AUTH_OPEN ? C_ORANGE : C_CYAN), bg);
  drawFit(buf, 6, y + 17, 1, maxW);
  rowRight(y, bg, a->rssi, stale);
}

void drawRowMesh(int y, uint16_t bg, int code) {
  int maxW = W - 106;
  char buf[48];
  tft.setTextDatum(TL_DATUM);
  if (code < 0) {                                        // MeshCore device in Wi-Fi OTA mode
    const AP *a = &vAp[-1 - code];
    bool stale = millis() - a->lastSeen > STALE_MS;
    tft.setTextColor(stale ? C_DIM : C_ORANGE, bg);
    drawFit(a->ssid, 6, y + 2, 2, maxW);
    snprintf(buf, sizeof(buf), "Wi-Fi OTA  ch%u  %s", a->ch, a->bssid);
    tft.setTextColor(C_DIM, bg);
    drawFit(buf, 6, y + 17, 1, maxW);
    rowRight(y, bg, a->rssi, stale);
    return;
  }
  const Dev *d = &vDev[code];
  bool stale = millis() - d->lastSeen > STALE_MS;
  const char *nm = d->name;
  if (d->mesh == MESH_COMPANION) nm += strlen(MESH_PREFIX);   // show the node name only
  tft.setTextColor(stale ? C_DIM : (d->mesh == MESH_COMPANION ? C_MAG : C_TEXT), bg);
  drawFit(nm[0] ? nm : "<NUS device>", 6, y + 2, 2, maxW);
  snprintf(buf, sizeof(buf), "%s  %s", d->mesh == MESH_COMPANION ? "companion" : "UART?", d->addr);
  tft.setTextColor(stale ? C_DIM : C_CYAN, bg);
  drawFit(buf, 6, y + 17, 1, maxW);
  rowRight(y, bg, d->rssi, stale);
}

void drawList() {
  int count = itemCount(mode);
  int maxScroll = max(0, count - ROWS);
  scrollPos = constrain(scrollPos, 0, maxScroll);

  for (int i = 0; i < ROWS; i++) {
    int y = LIST_Y + i * ROW_H;
    uint16_t bg = (i & 1) ? C_ROW_B : C_ROW_A;
    tft.fillRect(0, y, W, ROW_H, bg);
    int idx = scrollPos + i;
    if (idx >= count) continue;
    if (mode == M_BLE)       drawRowBLE(y, bg, &vDev[idx], false);
    else if (mode == M_TAGS) drawRowBLE(y, bg, &vDev[tagIdx[idx]], true);
    else if (mode == M_MESH) drawRowMesh(y, bg, meshIdx[idx]);
    else                     drawRowAP(y, bg, &vAp[idx]);
  }
  int yEnd = LIST_Y + ROWS * ROW_H;
  if (yEnd < FOOT_Y) tft.fillRect(0, yEnd, W, FOOT_Y - yEnd, C_BG);

  if (count == 0) {
    tft.setTextDatum(MC_DATUM);
    tft.setTextColor(C_DIM, C_ROW_B);
    const char *msg = paused ? "paused" : (mode == M_TAGS ? "no trackers nearby" : mode == M_MESH ? "no MeshCore nodes" : "scanning...");
    tft.drawString(msg, W / 2, LIST_Y + ROW_H + ROW_H / 2, 2);
  }
  drawScrollbar(count, scrollPos, ROWS);
}

// =====================================================================
// Drawing: channel analyzer
// =====================================================================
const uint16_t CH_PAL[] = { 0x07FF, 0xF81F, 0xFFE0, 0x07E0, 0xFD20, 0x867F, 0xFBEF, 0x5FFF };

int bestChannel() {
  int best = 1; long bestScore = LONG_MAX;
  const int cand[3] = { 1, 6, 11 };
  for (int c : cand) {
    long score = 0;
    for (int i = 0; i < vApCount; i++) {
      int d = abs((int)vAp[i].ch - c);
      if (vAp[i].ch <= 14 && d < 4) score += (long)(vAp[i].rssi + 100) * (4 - d);
    }
    if (score < bestScore) { bestScore = score; best = c; }
  }
  return best;
}

void drawChannels() {
  int top = LIST_Y, bottom = FOOT_Y;
  tft.fillRect(0, top, W, bottom - top, C_BG);

  int x0 = 26, x1 = W - 8;
  int y0 = top + 22, y1 = bottom - 20;
  int ch = y1 - y0;
  auto cx = [&](float c) { return (int)(x0 + c * (x1 - x0) / 14.0f); };
  auto ry = [&](int rssi) { return y1 - constrain(map(rssi, -100, -30, 0, ch), 0, ch); };

  tft.setTextDatum(MR_DATUM);
  tft.setTextColor(C_DIM, C_BG);
  for (int r = -90; r <= -30; r += 20) {
    int y = ry(r);
    for (int x = x0; x < x1; x += 4) tft.drawPixel(x, y, C_ROW_B);
    char b[6]; snprintf(b, sizeof(b), "%d", r);
    tft.drawString(b, x0 - 3, y, 1);
  }
  tft.drawFastHLine(x0, y1, x1 - x0, C_DIM);
  tft.setTextDatum(TC_DATUM);
  for (int c = 1; c <= 13; c++) {
    char b[4]; snprintf(b, sizeof(b), "%d", c);
    tft.drawFastVLine(cx(c), y1, 3, C_DIM);
    tft.setTextColor((c == 1 || c == 6 || c == 11) ? C_TEXT : C_DIM, C_BG);
    tft.drawString(b, cx(c), y1 + 5, 1);
  }

  for (int i = vApCount - 1; i >= 0; i--) {
    const AP &a = vAp[i];
    if (a.ch < 1 || a.ch > 14) continue;
    uint16_t col = CH_PAL[i % 8];
    int peak = ry(a.rssi);
    int px = -1, py = -1;
    for (int s = 0; s <= 16; s++) {
      float t = -2.0f + s * 0.25f;
      int x = cx(a.ch + t);
      int y = y1 - (int)((y1 - peak) * (1.0f - (t * t) / 4.0f));
      if (px >= 0) tft.drawLine(px, py, x, y, col);
      px = x; py = y;
    }
    if (i < 5) {
      tft.setTextDatum(BC_DATUM);
      tft.setTextColor(col, C_BG);
      drawFit(a.ssid[0] ? a.ssid : "<hidden>", cx(a.ch), max(y0 - 4, peak - 2), 1, 64);
    }
  }

  char b[32];
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(C_TEXT, C_BG);
  if (vApCount) snprintf(b, sizeof(b), "best channel: %d", bestChannel());
  else          snprintf(b, sizeof(b), paused ? "paused" : "scanning...");
  tft.drawString(b, 6, top + 4, 2);
}

void drawBody() {
  if (mode == M_CHAN) drawChannels();
  else drawList();
}

// =====================================================================
// Drawing: detail pages (with signal meter for hunting)
// =====================================================================
int detailLimitY = 320;

void detailLine(int &y, const char *label, const char *value, uint16_t col = C_TEXT) {
  if (y + 18 > detailLimitY) return;
  tft.fillRect(0, y, W, 18, C_BG);
  tft.setTextDatum(TL_DATUM);
  tft.setTextColor(C_DIM, C_BG);
  tft.drawString(label, 6, y + 4, 1);
  tft.setTextColor(col, C_BG);
  drawFit(value, 64, y, 2, W - 70);
  y += 19;
}

void drawMeter(int y, int rssi, bool lost) {
  tft.fillRect(0, y, W, 52, C_BG);
  char buf[16];
  if (lost) snprintf(buf, sizeof(buf), "LOST");
  else      snprintf(buf, sizeof(buf), "%d dBm", rssi);
  tft.setTextDatum(TC_DATUM);
  tft.setTextColor(lost ? C_RED : rssiColor(rssi), C_BG);
  tft.drawString(buf, W / 2, y + 2, 4);
  rssiBar(12, y + 34, W - 24, 12, lost ? -100 : rssi, lost ? C_DIM : rssiColor(rssi));
}

void drawDetail(bool full) {
  const Dev *d = nullptr;
  const AP *a = nullptr;
  if (detailMode == M_WIFI) {
    for (int i = 0; i < vApCount; i++) if (strcmp(vAp[i].bssid, selKey) == 0) { a = &vAp[i]; break; }
  } else {
    for (int i = 0; i < vDevCount; i++) if (strcmp(vDev[i].addr, selKey) == 0) { d = &vDev[i]; break; }
  }

  if (full) {
    tft.fillScreen(C_BG);
    tft.drawFastHLine(0, HEAD_H, W, C_CYAN);
    tft.setTextDatum(BC_DATUM);
    tft.setTextColor(C_DIM, C_BG);
    tft.drawString("tap anywhere to go back", W / 2, H - 4, 1);
  }
  detailLimitY = H - 14;
  drawHeader();
  int y = HEAD_H + 6;
  char buf[64], dur[16];

  if (detailMode == M_WIFI) {
    bool lost = !a || (millis() - a->lastSeen > STALE_MS);
    drawMeter(y, a ? a->rssi : -100, lost);
    y += 58;
    if (!a) return;
    detailLine(y, "SSID", a->ssid[0] ? a->ssid : "<hidden>");
    detailLine(y, "BSSID", a->bssid, C_CYAN);
    snprintf(buf, sizeof(buf), "%u  (2.4 GHz)", a->ch);
    detailLine(y, "Channel", buf);
    detailLine(y, "Security", encName(a->enc), a->enc == WIFI_AUTH_OPEN ? C_ORANGE : C_TEXT);
    fmtDuration(dur, sizeof(dur), millis() - a->lastSeen);
    snprintf(buf, sizeof(buf), "%u x, %s ago", a->hits, dur);
    detailLine(y, "Seen", buf);
    fmtDuration(dur, sizeof(dur), millis() - a->firstSeen);
    detailLine(y, "Known", dur);
    return;
  }

  bool lost = !d || (millis() - d->lastSeen > STALE_MS);
  drawMeter(y, d ? d->rssi : -100, lost);
  y += 58;
  if (!d) return;

  detailLine(y, "MAC", d->addr, C_CYAN);
  detailLine(y, "Name", d->name[0] ? d->name : "-");
  if (d->tag) detailLine(y, "Tracker", TAG_NAMES[d->tag], C_ORANGE);
  if (d->mesh) detailLine(y, "MeshCore", d->mesh == MESH_COMPANION ? "companion radio" : "UART service (maybe)", C_MAG);
  if (d->hasMfg) {
    const char *v = vendorName(d->mfgId);
    snprintf(buf, sizeof(buf), "0x%04X %s", d->mfgId, v ? v : "");
  } else strcpy(buf, "-");
  detailLine(y, "Vendor", buf, C_MAG);
  if (d->hasTx) snprintf(buf, sizeof(buf), "%d dBm", d->txPower); else strcpy(buf, "-");
  detailLine(y, "TX pwr", buf);
  detailLine(y, "Service", d->uuid[0] ? d->uuid : "-");
  fmtDuration(dur, sizeof(dur), millis() - d->lastSeen);
  snprintf(buf, sizeof(buf), "%u x, %s ago", d->hits, dur);
  detailLine(y, "Seen", buf);
  fmtDuration(dur, sizeof(dur), millis() - d->firstSeen);
  detailLine(y, "Nearby", dur, (d->tag && millis() - d->firstSeen > tagWarnMs()) ? C_MAG : C_TEXT);
  buf[0] = 0;
  for (int i = 0; i < d->mfgLen && i < 14; i++) {
    char h[4]; snprintf(h, sizeof(h), "%02X", d->mfg[i]); strcat(buf, h);
  }
  detailLine(y, "Mfg", d->mfgLen ? buf : "-", C_DIM);
}

// =====================================================================
// Touch calibration (3 crosses + 1 check), drawn in native portrait
// =====================================================================
#define CAL_M 20                      // cross distance from the screen edge

void calCross(int x, int y, uint16_t col) {
  tft.drawFastHLine(x - 12, y, 25, col);
  tft.drawFastVLine(x, y - 12, 25, col);
  tft.drawCircle(x, y, 6, col);
}

void calScreen(const char *step, const char *hint, int cx, int cy, uint16_t col) {
  tft.fillScreen(C_BG);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(C_MAG, C_BG);
  tft.drawString("TOUCH CALIBRATION", NW / 2, NH / 2 - 40, 2);
  tft.setTextColor(C_TEXT, C_BG);
  tft.drawString(hint, NW / 2, NH / 2 - 10, 2);
  tft.setTextColor(C_CYAN, C_BG);
  tft.drawString(step, NW / 2, NH / 2 + 20, 4);
  calCross(cx, cy, col);
}

// Wait for a press, average the raw values while pressed, wait for release.
// Returns false after 60 s without a touch.
bool calSample(int &ra, int &rb) {
  uint32_t t0 = millis();
  while (!touchDown()) { if (millis() - t0 > 60000) return false; delay(10); }
  long sa = 0, sb = 0; int n = 0;
  uint32_t t1 = millis();
  int a, b;
  while (millis() - t1 < 400 && touchRaw(a, b)) { sa += a; sb += b; n++; delay(10); }
  if (n == 0) { touchRaw(a, b); sa = a; sb = b; n = 1; }
  ra = sa / n; rb = sb / n;
  uint32_t up = millis();
  while (millis() - up < 150) { if (touchDown()) up = millis(); delay(10); }   // released for 150 ms
  return true;
}

// Pure maths, so it can be unit-tested on a PC
bool calCompute(const int a[3], const int b[3], int nw, int nh, TouchCal &c) {
  // points: 0 = top-left, 1 = top-right, 2 = bottom-left (all CAL_M from the edges)
  int dxA = abs(a[1] - a[0]), dxB = abs(b[1] - b[0]);
  c.swap = dxB > dxA;
  int u0 = c.swap ? b[0] : a[0], u1 = c.swap ? b[1] : a[1];
  int v0 = c.swap ? a[0] : b[0], v2 = c.swap ? a[2] : b[2];
  int uOther = c.swap ? abs(b[2] - b[0]) : abs(a[2] - a[0]);   // x-axis drift on the vertical move
  if (abs(u1 - u0) < 40 || abs(v2 - v0) < 40) return false;    // finger barely moved
  if (abs(v2 - v0) < 2 * uOther) return false;                  // axes don't line up
  int sx = nw - 1 - 2 * CAL_M, sy = nh - 1 - 2 * CAL_M;
  c.x0 = u0 - (long)(u1 - u0) * CAL_M / sx;
  c.x1 = u1 + (long)(u1 - u0) * CAL_M / sx;
  c.y0 = v0 - (long)(v2 - v0) * CAL_M / sy;
  c.y1 = v2 + (long)(v2 - v0) * CAL_M / sy;
  return true;
}

void runCalibration() {
  tft.setRotation(0);
  applyInvert();
  const int tx[3] = { CAL_M, NW - 1 - CAL_M, CAL_M };
  const int ty[3] = { CAL_M, CAL_M, NH - 1 - CAL_M };
  const char *steps[3] = { "1 / 3", "2 / 3", "3 / 3" };
  digitalWrite(LED_R, LOW); digitalWrite(LED_B, LOW);
  for (;;) {
    int a[3], b[3];
    bool ok = true;
    for (int i = 0; i < 3 && ok; i++) {
      calScreen(steps[i], "tap the centre of the cross", tx[i], ty[i], C_CYAN);
      ok = calSample(a[i], b[i]);
      Serial.printf("[cal] point %d raw %d,%d\n", i, a[i], b[i]);
    }
    if (!ok) break;                                   // nobody there: keep the old values
    TouchCal c;
    if (!calCompute(a, b, NW, NH, c)) {
      calScreen("again", "that didn't line up - once more", NW / 2, NH / 2 + 60, C_BG);
      delay(1500);
      continue;
    }
    // check with a 4th cross in the bottom-right corner
    TouchCal old = cal; cal = c;
    int cx = NW - 1 - CAL_M, cy = NH - 1 - CAL_M;
    calScreen("check", "tap the centre of the cross", cx, cy, C_GREEN);
    int ra, rb;
    if (!calSample(ra, rb)) { cal = old; break; }
    int px, py;
    rawToNative(ra, rb, px, py);
    int err = abs(px - cx) + abs(py - cy);
    Serial.printf("[cal] swap=%u x %d..%d  y %d..%d  check error %d px\n", c.swap, c.x0, c.x1, c.y0, c.y1, err);
    if (err <= 30) {
      saveCal();
      calScreen("saved", "calibration OK", NW / 2, NH / 2 + 60, C_BG);
      delay(900);
      break;
    }
    cal = old;
    calScreen("again", "not accurate enough - once more", NW / 2, NH / 2 + 60, C_BG);
    delay(1500);
  }
  digitalWrite(LED_R, HIGH); digitalWrite(LED_B, HIGH);
  while (touchDown()) delay(10);
}

// =====================================================================
// Settings
// =====================================================================
#define SET_ROWS 9
int setRowH() { return (FOOT_Y - HEAD_H - 4) / SET_ROWS; }

void settingValue(int i, char *b, size_t n) {
  switch (i) {
    case 0: if (set.minRssi) snprintf(b, n, "%d dBm", OPT_MINRSSI[set.minRssi]); else strlcpy(b, "off", n); break;
    case 1: strlcpy(b, set.hideStale ? "on" : "off", n); break;
    case 2: snprintf(b, n, "%us", OPT_SCAN[set.scan]); break;
    case 3: if (OPT_FORGET[set.forget] >= 60) snprintf(b, n, "%u min", OPT_FORGET[set.forget] / 60);
            else snprintf(b, n, "%us", OPT_FORGET[set.forget]); break;
    case 4: snprintf(b, n, "%u min", OPT_TAG[set.tag]); break;
    case 5: snprintf(b, n, "%u%%", OPT_BRIGHT[set.bright]); break;
    case 6: strlcpy(b, set.invert ? "on" : "off", n); break;
    case 7: strlcpy(b, "start", n); break;
    default: b[0] = 0;
  }
}

const char *SET_LABELS[SET_ROWS] = {
  "Min signal", "Hide stale", "Scan time", "Forget after",
  "Tracker alert", "Brightness", "Invert colours", "Calibrate touch",
  "Reset to defaults"
};

void drawSettingRow(int i) {
  int rh = setRowH(), y = HEAD_H + 4 + i * rh;
  uint16_t bg = (i & 1) ? C_ROW_B : C_ROW_A;
  tft.fillRect(0, y, W, rh, bg);
  tft.setTextDatum(ML_DATUM);
  if (i == SET_ROWS - 1) {
    tft.setTextColor(C_ORANGE, bg);
    tft.drawString(SET_LABELS[i], 8, y + rh / 2, 2);
    return;
  }
  tft.setTextColor(C_TEXT, bg);
  tft.drawString(SET_LABELS[i], 8, y + rh / 2, 2);
  char v[16];
  settingValue(i, v, sizeof(v));
  int vw = tft.textWidth(v, 2) + 14;
  int vx = W - 8 - vw;
  tft.drawRoundRect(vx, y + rh / 2 - 9, vw, 18, 4, C_CYAN);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(C_CYAN, bg);
  tft.drawString(v, vx + vw / 2, y + rh / 2 + 1, 2);
}

void drawSettings() {
  tft.fillScreen(C_BG);
  drawHeaderLeft();
  drawHeaderRight("SETTINGS", C_MAG);
  tft.drawFastHLine(0, HEAD_H, W, C_CYAN);
  for (int i = 0; i < SET_ROWS; i++) drawSettingRow(i);
  tft.fillRect(0, FOOT_Y, W, FOOT_H, C_BG);
  tft.drawFastHLine(0, FOOT_Y, W, C_CYAN);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(C_MAG, C_BG);
  tft.drawString("BACK", W / 2, FOOT_Y + FOOT_H / 2 + 1, 2);
}

void settingTap(int i) {
  switch (i) {
    case 0: set.minRssi   = (set.minRssi + 1) % 4; break;
    case 1: set.hideStale = !set.hideStale; break;
    case 2: set.scan      = (set.scan + 1) % 3; break;
    case 3: set.forget    = (set.forget + 1) % 3; break;
    case 4: set.tag       = (set.tag + 1) % 4; break;
    case 5: set.bright    = (set.bright + 1) % 4; setBacklight(); break;
    case 6: set.invert    = !set.invert; applyInvert(); break;
    case 7: runCalibration(); applyRotation(); drawSettings(); return;
    case 8: set = Settings(); setBacklight(); applyInvert(); saveSettings(); drawSettings(); return;
  }
  saveSettings();
  drawSettingRow(i);
}

// =====================================================================
// Full redraw per screen
// =====================================================================
void fullRedraw() {
  switch (screen) {
    case DETAIL:   drawDetail(true); return;
    case SETTINGS: drawSettings();   return;
    default:
      tft.fillScreen(C_BG);
      drawHeader();
      drawTabs();
      drawFooter();
      drawBody();
  }
}

// =====================================================================
// Boot screen + crash diagnostics
// =====================================================================
#define BOOT_MAGIC 0x6EEC4B00
RTC_NOINIT_ATTR uint32_t bootMagic;
RTC_NOINIT_ATTR uint32_t bootStep;
uint32_t prevBootStep = 0;                      // step the previous boot reached
const char *STEP_NAMES[] = { "start", "display", "touch", "wi-fi", "bluetooth", "scanner", "running" };

void bootMark(uint32_t step) {
  bootMagic = BOOT_MAGIC; bootStep = step;
  Serial.printf("[boot] %s  free heap %u  largest block %u\n", STEP_NAMES[step],
                (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMaxAllocHeap());
}

// Version line in the dark band at the bottom of the boot image
void splashVersion() {
  tft.setTextColor(C_CYAN);                       // transparent background over the image
#if SPLASH_W > 240
  tft.setTextDatum(MC_DATUM);
  tft.drawString(FW_AUTHOR "  v" FW_VERSION, SPLASH_W / 2, SPLASH_H - 21, 2);
#else
  tft.setTextDatum(BC_DATUM);
  tft.drawString(FW_AUTHOR "  v" FW_VERSION, SPLASH_W / 2, SPLASH_H - 1, 1);
#endif
}

// If the last restart was a crash, show why on the boot screen
void showLastCrash() {
  esp_reset_reason_t r = esp_reset_reason();
  const char *why = nullptr;
  switch (r) {
    case ESP_RST_PANIC:    why = "CRASH"; break;
    case ESP_RST_BROWNOUT: why = "POWER DIP (brownout)"; break;
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:      why = "WATCHDOG"; break;
    default: break;
  }
  if (!why) return;
  char b[64];
  uint32_t st = prevBootStep;
  snprintf(b, sizeof(b), "last restart: %s at %s", why, STEP_NAMES[st]);
  Serial.println(b);
  tft.fillRect(0, 0, SPLASH_W, 14, C_RED);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE, C_RED);
  tft.drawString(b, SPLASH_W / 2, 7, 1);
}
// Wait on the boot image for a tap. Returns true for a 3-second hold
// (= start touch calibration).
bool waitForTouch() {
  while (touchDown()) delay(10);
  uint32_t t0 = millis();
  while (!touchDown()) {
    bool on = ((millis() - t0) / 600) % 2 == 0;
    digitalWrite(LED_R, on ? LOW : HIGH);
    digitalWrite(LED_B, on ? LOW : HIGH);
    delay(20);
  }
  digitalWrite(LED_R, HIGH); digitalWrite(LED_B, HIGH);
  uint32_t down = millis(), up = millis();
  bool hold = false;
  while (millis() - up < 150) {                   // until released for 150 ms
    if (touchDown()) up = millis();
    if (!hold && millis() - down > 3000) {
      hold = true;
      tft.fillRect(0, SPLASH_H / 2 - 14, SPLASH_W, 28, C_MAG);
      tft.setTextDatum(MC_DATUM);
      tft.setTextColor(TFT_WHITE, C_MAG);
      tft.drawString("release to calibrate touch", SPLASH_W / 2, SPLASH_H / 2, 2);
    }
    delay(10);
  }
  return hold;
}

// =====================================================================
// Setup / loop
// =====================================================================
void setup() {
  Serial.begin(115200);
  Serial.println();
  Serial.println("==============================");
  Serial.println("  " FW_AUTHOR " " FW_NAME " v" FW_VERSION);
  Serial.println("  board: " BOARD_NAME);
  Serial.println("==============================");

  pinMode(LED_R, OUTPUT); pinMode(LED_G, OUTPUT); pinMode(LED_B, OUTPUT);
  digitalWrite(LED_R, HIGH); digitalWrite(LED_G, HIGH); digitalWrite(LED_B, HIGH);

  prevBootStep = (bootMagic == BOOT_MAGIC && bootStep < 7) ? bootStep : 0;
  prefs.begin("geekaboo", false);
  rot = prefs.getUChar("rot", 0) & 3;
  loadSettings();

  bootMark(1);
  tft.init();
  NW = tft.width(); NH = tft.height();            // native portrait size
  applyInvert();
  ledcAttach(BL_PIN, 5000, 8);
  setBacklight();
  tft.setRotation(2);                             // boot image: portrait, flipped 180 degrees
  tft.setSwapBytes(true);
  tft.pushImage(0, 0, SPLASH_W, SPLASH_H, splashImg);
  splashVersion();
  showLastCrash();

  bootMark(2);
  touchBegin();
  loadCal();

  dataMutex = xSemaphoreCreateMutex();
#ifndef EMU_TEST
  bootMark(4);                                    // Bluetooth first: it needs the biggest memory block
  BLEDevice::init("Geekaboo-Scanner");
  bleScan = BLEDevice::getScan();
  bleScan->setAdvertisedDeviceCallbacks(new ScanCB(), true);
  bleScan->setActiveScan(true);
  bleScan->setInterval(100);
  bleScan->setWindow(99);

  bootMark(3);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  bool hold = waitForTouch();
  if (hold || (CAL_REQUIRED && !haveCal())) runCalibration();
#endif

  bootMark(5);
  applyRotation();
#ifndef EMU_TEST
  xTaskCreatePinnedToCore(scanTask, "scan", 8192, nullptr, 1, nullptr, 0);
#endif
  fullRedraw();
  bootMark(6);
}

void handleListTouch(int x, int y) {
  if (y >= HEAD_H && y < HEAD_H + TAB_H) {                  // tabs
    Mode m = (Mode)constrain(x / (W / M_COUNT), 0, M_COUNT - 1);
    if (m != mode) {
      mode = m;
      scrollPos = 0;
      takeSnapshot();
      drawHeader(); drawTabs(); drawBody();
    }
  } else if (y >= FOOT_Y) {                                 // footer buttons
    int b = constrain(x / (W / 5), 0, 4);
    switch (LIST_BTNS[b]) {
      case B_UP:    scrollPos -= ROWS; break;
      case B_DOWN:  scrollPos += ROWS; break;
      case B_PAUSE: paused = !paused; drawFooter(); break;
      case B_ROT:
        rot = (rot + 1) & 3;
        prefs.putUChar("rot", rot);
        applyRotation();
        fullRedraw();
        return;
      case B_SET:
        screen = SETTINGS;
        fullRedraw();
        return;
      default: break;
    }
    drawHeader();
    drawBody();
  } else if (y >= LIST_Y && mode != M_CHAN) {               // list row
    int row = (y - LIST_Y) / ROW_H;
    int idx = scrollPos + row;
    if (row < ROWS && idx < itemCount(mode)) {
      bool apSel = (mode == M_WIFI) || (mode == M_MESH && meshIdx[idx] < 0);
      if (mode == M_BLE)       strlcpy(selKey, vDev[idx].addr, sizeof(selKey));
      else if (mode == M_TAGS) strlcpy(selKey, vDev[tagIdx[idx]].addr, sizeof(selKey));
      else if (mode == M_MESH) {
        int c = meshIdx[idx];
        strlcpy(selKey, c < 0 ? vAp[-1 - c].bssid : vDev[c].addr, sizeof(selKey));
      }
      else                     strlcpy(selKey, vAp[idx].bssid, sizeof(selKey));
      detailMode = apSel ? M_WIFI : M_BLE;
      screen = DETAIL;
      drawDetail(true);
    }
  }
}

void handleDetailTouch(int x, int y) {
  screen = LIST;
  takeSnapshot();
  fullRedraw();
}

void loop() {
  static uint32_t lastDraw = 0;
  int x, y;

  if (newTagSeen) { newTagSeen = false; tagFlashUntil = millis() + 200; digitalWrite(LED_R, LOW); }
  if (tagFlashUntil && millis() > tagFlashUntil) { tagFlashUntil = 0; digitalWrite(LED_R, HIGH); }

#ifdef EMU_TEST
  // scripted taps, relative to the current screen size:
  // tabs, pause x2, settings, every setting row except "Calibrate", back, rotate x4
  static int step = 0; static uint32_t tNext = 0;
  const int N_STEPS = 21;
  bool fake = false;
  if (millis() > tNext && step < N_STEPS) {
    int bw = W / 5, fy = H - FOOT_H / 2;
    if (step < 5)        { x = ((step + 1) % 5) * bw + bw / 2; y = HEAD_H + TAB_H / 2; }
    else if (step < 7)   { x = bw + bw / 2;     y = fy; }
    else if (step == 7)  { x = 3 * bw + bw / 2; y = fy; }
    else if (step < 16)  { int i = step - 8; if (i >= 7) i++;          // skip row 7
                           x = W / 2; y = HEAD_H + 4 + i * setRowH() + setRowH() / 2; }
    else                 { x = W / 2; y = fy; }                         // back, then rotate x4
    fake = true; tNext = millis() + 400;
    Serial.printf("[emu] tap %d (%d,%d) screen=%d %dx%d heap=%u\n", step, x, y, (int)screen, W, H,
                  (unsigned)ESP.getFreeHeap());
    step++;
    if (step == N_STEPS) Serial.println("[emu] ALL TAPS DONE");
  }
  if (fake || getTouch(x, y)) {
#else
  if (getTouch(x, y)) {
#endif
    switch (screen) {
      case LIST:     handleListTouch(x, y); break;
      case DETAIL:   handleDetailTouch(x, y); break;
      case SETTINGS:
        if (y >= FOOT_Y) { screen = LIST; takeSnapshot(); fullRedraw(); }
        else if (y >= HEAD_H + 4) {
          int i = (y - HEAD_H - 4) / setRowH();
          if (i < SET_ROWS) settingTap(i);
        }
        break;
    }
  }

  uint32_t now = millis();
  switch (screen) {
    case LIST:
      if (now - lastDraw > 1000) {
        lastDraw = now;
        if (!paused) takeSnapshot();
        drawHeader(); drawBody();
      }
      break;
    case DETAIL:
      if (now - lastDraw > 500) { lastDraw = now; takeSnapshot(); drawDetail(false); }
      break;
    default: break;
  }
}
