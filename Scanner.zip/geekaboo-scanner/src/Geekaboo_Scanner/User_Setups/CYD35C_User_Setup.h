// TFT_eSPI config: ESP32-3248S035C CYD 3.5" 320x480 ST7796. Copy over libraries/TFT_eSPI/User_Setup.h
// Pins from TFT_eSPI Setup77 (same ESP32 3.5" ST7796 layout) and the Sunton board definition.
#define ST7796_DRIVER
#define TFT_WIDTH  320
#define TFT_HEIGHT 480
#define TFT_MISO 12
#define TFT_MOSI 13
#define TFT_SCLK 14
#define TFT_CS   15
#define TFT_DC    2
#define TFT_RST  -1
#define TFT_BL   27
#define TFT_BACKLIGHT_ON HIGH
// Touch is a GT911 on I2C (handled in the sketch), so no TOUCH_CS here
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define LOAD_GFXFF
#define SMOOTH_FONT
#define SPI_FREQUENCY       27000000
#define SPI_READ_FREQUENCY  16000000
#define SPI_TOUCH_FREQUENCY  2500000
